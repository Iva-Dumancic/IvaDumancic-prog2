import funkcije

ime=input("Unesi svoje ime:")
poruke.ispisi_poruku(funkcije.pozdrav,ime)
